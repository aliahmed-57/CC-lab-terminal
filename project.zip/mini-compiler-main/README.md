# Mini-Compiler
C# mini-compiler WinForm Program.

**Functionalities**
--
• Scanning
• Semantic Analyzing
• Display Memory
• Reset

**Demo**
--


https://user-images.githubusercontent.com/66283081/176023766-2c3f8c25-67ff-44dc-8e32-36a62202ff98.mp4

